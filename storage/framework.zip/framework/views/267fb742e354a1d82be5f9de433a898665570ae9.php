<div>
    <div class="modal fade" id="frate-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Other Expenses</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body" >
        <label class="font-weight-bold ">Frate Expenses</label> 
        <input type="number" id="Frate" class="form-control" placeholder="Frate Expenses" autofocus>
        <label class="font-weight-bold mt-2">Laborer Expenses</label> 
        <input type="number" id="Laborer" class="form-control" placeholder="Laborer Expenses">
        <label class="font-weight-bold mt-2">Other Expenses </label> 
        <input type="number" id="other" class="form-control" placeholder="Other Expenses" > 
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-primary" id="other_expenses">Apply discount</button>
      </div>
    </div>
  </div>
</div>
</div><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/frate-component.blade.php ENDPATH**/ ?>