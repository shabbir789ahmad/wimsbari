<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-12">
		<div class="form-group">
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.btn.link-create','data' => ['route' => 'wherehouse.create']]); ?>
<?php $component->withName('btn.link-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'wherehouse.create']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
		</div>
	</div>
</div>
	
<div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body pb-1">
				<?php if(count($wherehouses) > 0): ?>
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead class="thead-light">
								<tr>
									
									<th scope="col">WhereHouse Name</th>
									<th scope="col">WhereHouse Location</th>
									
									<th scope="col"></th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $wherehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wherehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									
									<td><?php echo e($wherehouse->where_house_name); ?></td>
									<td><?php echo e($wherehouse->where_house_location); ?></td>
									
									<td>
										<a href="<?php echo e(route('wherehouse.edit', ['wherehouse' => $wherehouse->id])); ?>" type="submit" class="btn btn-md btn-info">
										Edit
									</a>
										<form action="<?php echo e(route('wherehouse.destroy', ['wherehouse' => $wherehouse->id])); ?>" method="POST" class="d-inline" >
											
											<?php echo csrf_field(); ?>
											<?php echo method_field('Delete'); ?>
											<button type="submit" class="btn  btn-danger">
												Delete
											</button>
										</form>
										
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				<?php else: ?>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => ' WhereHouse','new' => 'wherehouse.create']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => ' WhereHouse','new' => 'wherehouse.create']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php endif; ?>			
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/wherehouse/index.blade.php ENDPATH**/ ?>