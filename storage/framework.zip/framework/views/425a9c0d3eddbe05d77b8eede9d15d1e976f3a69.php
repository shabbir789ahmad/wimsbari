<div>
 
                <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
                            <tr>
                                <th scope="col"><input type="checkbox" id="select_all"></th>
                                <th scope="col"></th>
                                <th scope="col">Brand</th>
                                <th scope="col">Name</th>
                  
                                <th scope="col">Category</th>
                                <th scope="col">Sub Category</th>
                                <th scope="col">Stock</th>
                                <th scope="col">Sold</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               
                                <td> <?php $__currentLoopData = $product->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="checkbox" name="product_brand[]" class="product_brand d-none" value="<?php echo e($b['id']); ?>" >
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    <input type="checkbox" class="product_checkbox" name="id[]" value="<?php echo e($product->id); ?>"></td>
                                </form>
                                <td class="text-center">
                                    <img src="<?php echo e(asset('uploads/products/' . $product->product_image)); ?>" class="img-fluid img-thumbnail" alt="" style="width: 64px;" loading="lazy">
                                </td>
                                <td >
                                  <select class="form-control brands" >
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $product->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($brand['id'] ==  $b['brand_id'] ): ?>
                                     <option value="<?php echo e($b['id']); ?>"><?php echo e($brand['brand_name']); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </td>
                                <td>
                                    <?php if(strstr($product->product_name, '/')): ?>
                                        <?php echo App\Helpers\Fraction::frac($product->product_name); ?>

                                    <?php else: ?>
                                        <?php echo e($product->product_name); ?>

                                    <?php endif; ?>
                                </td>
                               
                                <td>
                                    <?php echo e($product->category_name); ?>

                                </td>
                                <td>
                                    <?php echo e($product->sub_category_name); ?>

                                </td>
                                <td>
                                  <select class="form-control">
                                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $product->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($stock['pbrand_id'] == $b['id']): ?>
                                     <option><?php echo e($stock['stock']); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                  </select>
                                    
                                </td>
                                <td class="col-1">
                                    <select class="form-control">
                                        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $product->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($stock['pbrand_id'] == $b['id']): ?>
                                    <?php if($stock['stock_sold']==Null || $stock['stock_sold']==''): ?>
                                     <option>0</option>
                                    <?php else: ?>
                                     <option><?php echo e($stock['stock_sold']); ?></option>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>
                                </td>
                                <td class="">
                               
                                    <a href="<?php echo e(route('products.edit', ['id' => $product->id])); ?>" type="submit" class="btn btn-xs btn-info">
                                        Edit
                                    </a>
                                    <form action="<?php echo e(route('products.destroy', ['id' => $product->id])); ?>" method="POST" class="d-inline" >
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-xs btn-danger">
                                            Delete
                                        </button>
                                    </form>
                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
          </table>
</div><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/same-code3.blade.php ENDPATH**/ ?>