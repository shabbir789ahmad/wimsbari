<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-lg-3 col-6">
		<div class="small-box bg-primary">
			<div class="inner">
				<h3><?php echo e($data['brands']); ?></h3>
				<p>Brands</p>
			</div>
			<div class="icon">
				<i class="fas fa-copyright"></i>
			</div>
			<a href="<?php echo e(route('brands.index')); ?>" class="small-box-footer">
				More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-6">
		<div class="small-box bg-info">
			<div class="inner">
				<h3><?php echo e($data['categories']); ?></h3>
				<p>Categories</p>
			</div>
			<div class="icon">
				<i class="fas fa-layer-group"></i>
			</div>
			<a href="<?php echo e(route('categories.index')); ?>" class="small-box-footer">
				More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-6">
		<div class="small-box bg-success">
			<div class="inner">
				<h3><?php echo e($data['products']); ?></h3>
				<p>Products</p>
			</div>
			<div class="icon">
				<i class="fas fa-tags"></i>
			</div>
			<a href="<?php echo e(route('products.index')); ?>" class="small-box-footer">
				More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-6">
		<div class="small-box bg-olive">
			<div class="inner">
				<h3><?php echo e($data['suppliers']); ?></h3>
				<p>Suppliers</p>
			</div>
			<div class="icon">
				<i class="fas fa-truck"></i>
			</div>
			<a href="<?php echo e(route('suppliers.index')); ?>" class="small-box-footer">
				More info <i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/dashboard/index.blade.php ENDPATH**/ ?>