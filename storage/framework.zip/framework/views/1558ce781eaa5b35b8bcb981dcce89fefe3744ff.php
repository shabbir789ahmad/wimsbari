<?php $__env->startSection('content'); ?>


<div class="row">
 <div class="col-md-4">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.same-code','data' => ['categories' => $categories]]); ?>
<?php $component->withName('same-code'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 </div>
 <div class="col-12 col-md-4">
   <div class="form-group">
    <label for="">Search by Sub Category <span class="text-danger">*</span>
    </label>
    <select name="sub_category_id[]" id="sub_category_id" class="form-control sub_category_id " multiple>
        <?php if(request()->query('sub_category')): ?>

        <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($subcategory['id']); ?>" <?php if(request()->query('sub_category')==$subcategory->id): ?> selected <?php endif; ?>><?php echo e($subcategory['sub_category_name']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
   </div>
  </div>
  <div class="col-md-4">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.same-code2','data' => ['brands' => $brands]]); ?>
<?php $component->withName('same-code2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['brands' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($brands)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
  </div>
</div>
<div class="row">
	<div class="col-12">
		<div class="card">

			<form action="<?php echo e(route('products.get2')); ?>" method="Get">
			<button class="btn btn-primary mt-2 ml-4 create-new-product"  style="width:20%">
					Update Products
			</button>
			<div class="card-body pb-0">
				<?php if(count($products) > 0): ?>
                
				  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.same-code3','data' => ['products' => $products,'brands' => $brands,'stocks' => $stocks]]); ?>
<?php $component->withName('same-code3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'brands' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($brands),'stocks' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stocks)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php else: ?>
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => 'products','new' => 'products.create-bulk']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => 'products','new' => 'products.create-bulk']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php endif; ?>			
			</div>
		</div>
	</div>
</div>
<form id="sub_category_form">
	<input type="hidden" name="sub_category" id="sub_category">
	<input type="hidden" name="brand_se" id="brand_se">
	<input type="hidden" name="category" id="category">
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>

<script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": false,
        "info":     false
    } );
} );

 $("#select_all").click(function(){
        $("input[type=checkbox]").prop('checked', $(this).prop('checked'));
     // let brn= $('.brands').val()
     // $(this).parents('#example').children('tbody').children('tr').find('.product_brand').val(brn)
});

 $('.create-new-product').click(function(){

    var checked = $("input[type=checkbox]:checked").length;
 

    if(checked)
    {
    	$('create-new-product').prop('disabled',false);
    }
    else{

    	
    	alert ('please Check at Least One product')
      $(this).prop('disabled',true);
    }


 });


  $('#brand_search').change(function(e){
  	e.preventDefault();
  
  	var values = [];
        $.each($("#sub_category_id option:selected"), function(){            
            values.push($(this).val());
        });

    //alert (values)
  	 $('#sub_category').val(values)

  	let idc=$('#category_id').val()
  	$('#category').val(idc)

  	let id=$(this).val()
  	$('#brand_se').val(id)
  	$('#sub_category_form').submit()
  });





</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/products/update_bulk.blade.php ENDPATH**/ ?>