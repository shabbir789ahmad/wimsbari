<style type="text/css">
    th, td {
  padding: 15px;
}
</style>

<div class="row mt-0 pt-0 printer" id="printer">
 
<div class="container-fluid " id="">
     <div  style="font-size: 4vw; font-weight: 700; text-align:center; margin: 0mm; padding: 0mm; text-decoration: underline; display: flex; flex-direction:row; justify-content:space-between;">
        <img src="<?php echo e(asset('assets/defaults/logo.avif')); ?>" width="60%">
        <strong class="mt-5 ">Delivery Challan</strong>
        </div>
    
       <!--  <div class="card-header " style=" display: flex; flex-direction: row; justify-content: center; text-align:center; padding: 0mm; margin: 0mm; text-decoration: underline;"><span style="font-size: 8vw; font-weight: 700; font-family: Open Sans;">BARI</span> <span style="font-size:6vw;margin: 9mm ; margin-left: 1%;">Engineering</span> 
        </div>
       
       <div class="" style="display:flex; justify-content:center; text-align:center; margin: 0mm; padding: 0mm;">
        
          <div style="display:flex; font-size: 3vw;flex-direction: column;margin: 0mm; padding: 0mm;">
                    
          <h4 class="heading" >TOTAL STORAGE SOLUTION</h4>
          <h4 class="heading text-secondary" >THE BRILLIENT USE OF SPACE</h4>
        </div>
      </div> -->

      <div class="" style="display:flex; justify-content:space-between; flex-direction: row;  margin-top: 0%; padding-top: 0%;">
        
           <p style=" font-size: 3vw; display:flex; flex-direction:row; margin-left: auto;"><strong>Date#:</strong>  <?php echo e(date('y.m.d H:m:s A')); ?></p>
       
      </div>
     

        <!-- <div  style="font-size: 3vw; font-weight: 700;  margin: 0mm; text-decoration: underline;">To:  <span id="client_name"></span>
        </div>   -->
      <div class="challan_detail">
        <div class="details_challan col-2">
         <strong>Sr#:</strong>
         <strong>___________</strong>

        </div>
        <div class="details_challan col-8">
         <strong>Follower Person:</strong>
         <strong>__________________________________</strong>
        </div>
        <div class="details_challan col-2">
         <strong>Vehicle:</strong>
         <strong >__________________</strong>
        </div>
    </div>
     <div class="challan_detail mt-4">
        <div class="details_challan col-4">
         <strong>Driver Name:</strong>
         <strong>__________________</strong>

        </div>
        <div class="details_challan col-4">
         <strong>Dricver CNIC:</strong>
         <strong>________________</strong>
        </div>
        <div class="details_challan col-4">
         <strong>Driver Mob #:</strong>
         <strong >_________________</strong>
        </div>
    </div>
     <div class="challan_detail mt-4">
        <div class="details_challan col-4">
         <strong>Purchase order#:</strong>
         <strong>_____________</strong>

        </div>
        <div class="details_challan col-4">
         <strong>Producttion order:</strong>
         <strong>_____________</strong>
        </div>
        <div class="details_challan col-4">
         <strong>Fitting Person:</strong>
         <strong >_____________</strong>
        </div>
    </div>
     
    <table class="table  " cellspacing="0" cellpadding="0">
  <thead>
    <tr class="table_header" >
      <th class="col-1 border-right"  >Sr No</th>
      <th class="col-8">Description</th>
      <th class="col-2">Size</th>
      <th class="col-1">Qty.</th>
    </tr>
  </thead>
  <tbody  id="bari_recipt">
    
   
    
   
  
  </tbody>
</table>

 
    
    <div style="position:absolute; bottom:15%; width: 100%;">
     <div class="" style="display:flex; flex-direction: row; justify-content: space-between; font-size: 3vw; font-weight: 700; text-decoration:overline;">
        <div >SIGNATURE</div>
        <div >RECIVED BY:</div>
      </div>
      
      <div class="term_conditon2" >
       <p style="margin-top: 18mm;"><strong>Office & Display Address:99-Shair Ali Road Near Of Expo Center,Joher Town, Lahore.</strong></p><br>
       <p style="margin-top:8mm"><strong>Factory Address: 36-km Main Multan Road, Lahore.</strong></p>
       <p style="margin-top:14mm"><strong>Cell No: 0302-4448392, 0333-9833392 </strong></p>
       <p style="margin-top:15mm"><strong>Email Address : bariengineering@gmail.com Web: www.baristeelrack.com</strong></p>
      </div>

      
    </div>
   
</div>

  </div><?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/components/reciept/deliverychallan.blade.php ENDPATH**/ ?>