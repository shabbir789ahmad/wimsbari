<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-12">
		<div class="form-group">
			<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.btn.link-create','data' => ['route' => 'user.create']]); ?>
<?php $component->withName('btn.link-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => 'user.create']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body pb-1">
				<?php if(count($users) > 0): ?>
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead class="thead-light">
								<tr>
									<th scope="col">User Name</th>
									<th scope="col">User Email</th>
									<th scope="col">User Role</th>
									<!-- <th scope="col">User Address</th> -->
									
									<th scope="col"></th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if(!empty($user->getRoleNames())): ?>
                                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($v=='admin'): ?>

                                <?php else: ?>
								<tr>
									
									<td><?php echo e(ucfirst($user->name)); ?></td>
									<td><?php echo e($user->email); ?></td>
									
								 
                              <td> <label class="badge badge-success"><?php echo e($v); ?></label></td>
                            
									
									<td>
										<a href="<?php echo e(route('user.edit', ['id' => $user->id])); ?>" type="submit" class="btn btn-md btn-info">
										Edit
									</a>
										<form action="<?php echo e(route('user.delete', ['id' => $user->id])); ?>" method="POST" class="d-inline" >
											
											<?php echo csrf_field(); ?>
											<?php echo method_field('Delete'); ?>
											<button type="submit" class="btn  btn-danger">
												Delete
											</button>
										</form>
										
									</td>
								</tr>
								<?php endif; ?>
								 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				<?php else: ?>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => 'users','new' => 'user.create']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => 'users','new' => 'user.create']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php endif; ?>			
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/user/index.blade.php ENDPATH**/ ?>