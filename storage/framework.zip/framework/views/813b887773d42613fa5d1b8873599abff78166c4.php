<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('products.Bulk-update')); ?>"  method="POST" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>

<div class="card" >
	<div class="card-body">
   <div class="row">
  	<div class="col-12 col-md-4">
				<div class="form-group">
					<label for="">
					 Product Brand<span class="text-danger">*</span>
					</label>
					<select class="form-control " id="brand"  name="">
						<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($brand['id']); ?>"><?php echo e($brand['brand_name']); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					
				</div>
			</div>
			<div class="col-12 col-md-4">
				<div class="form-group">
					<label for="">
						Product Category <span class="text-danger">*</span>
					</label>
					<select class="form-control " name="category_id[]">
						<?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($product['category_id']==$category['id']): ?>
						<?php if($loop->first): ?>
						<option value="<?php echo e($category['id']); ?>"><?php echo e($category['category_name']); ?></option>
            <?php endif; ?>
            <?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

						<?php endif; ?>
					</select>
				</div>
			</div>
      <div class="col-12 col-md-4">
				<div class="form-group">
					<label for="">
						Product Sub category<span class="text-danger">*</span>
					</label>
					<select class="form-control sub_cat_form" >
						<?php $__empty_1 = true; $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($product['sub_category_id']==$sub_category['id']): ?>

						<option value="<?php echo e($sub_category['id']); ?>" ><?php echo e($sub_category['sub_category_name']); ?></option>
						
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

						<?php endif; ?>
					</select>
				</div>
			</div>
		
    </div>
	</div>
</div>
<div id="product-field" class="col-12">
  <div class="row">
	  <div class="col-12 ">
		  <div class="card">
			  <div class="card-body pb-0">
				  <div class="form-group">
					  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.btn.save','data' => ['type' => 'submit']]); ?>
<?php $component->withName('btn.save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				  </div>
			  </div>
		  </div>
	  </div>
  </div>
</div>
<!--product-->
 <div class="row">
  <div class="col">
   <?php if($products): ?>
   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="card mt-5">
	 <div class="card-body">
	 	<div class="row d-none">
	 		<div class="col-12 col-md-4">
				<div class="form-group">
					<input type="text" class="" name="id[]" value="<?php echo e($product['id']); ?>">
				</div>
			</div>
			<div class="col-12 col-md-4">
				<div class="form-group">
					<?php if($product->brand): ?>
					<input type="text" name="pbrand_id[]" value="<?php echo e($product->brand->id); ?>" class="form-control"  >
					<?php else: ?>
            <input type="text" name="pbrand_id[]"  value="" class="form-control"  >
					<?php endif; ?>
				</div>
			</div>
		
		 </div>
	   <div class="row">
			<div class="col-12 col-md-6">
				<div class="form-group">
					<label for="">
						Product Name <span class="text-danger">*</span>
					</label>
					<?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'name[]','value' => ''.e($product['product_name']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
				</div>
			</div>
			
			<div class="col-12 col-md-6 ">
				<div class="form-group">
					<label for="">
						 Price Per Component  <span class="text-danger">*</span>
					</label>
					<?php if($product->brand): ?>
					<?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece[]','value' => ''.e(\App\Models\ProductStock::where(['pbrand_id' => $product->brand->id])->pluck('product_price_piece')->first()).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
					<?php else: ?>
           <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece[]','value' => '']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
					<?php endif; ?>
				</div>
			</div>

			<div class="col-12 col-md-6">
				<div class="form-group">
					<label for="">
						Component Stock<span class="text-danger">*</span>
					</label>
				    <input type="text" name="stock[]" value=" <?php echo e(\App\Models\ProductStock::where(['pbrand_id' => $product->brand->id])->pluck('stock')->first()); ?> " class="form-control">
				</div>
			</div>

			<div class="col-12 col-md-6">
				<div class="form-group">
					<label for="">
						Purchasing Price<span class="text-danger">*</span>
					</label>
					<?php if($product->brand): ?>
					<input type="text" name="purchasing_price[]" value="<?php echo e(\App\Models\ProductStock::where(['pbrand_id' => $product->brand->id])->pluck('purchasing_price')->first()); ?>" class="form-control">
					<?php else: ?>
           <input type="text" name="purchasing_price[]" value="" class="form-control">

					<?php endif; ?>
				</div>
			</div>
		 </div>
		
		
	 </div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
	</div>
  </div>
</form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>

<script type="text/javascript">
	
	$('#brand').change(function(){
   
    let brand=$(this).val()
    let text=$("#brand option:selected").text();
    $('#b_id').val(brand)
    $('#b').val(text)
   
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/products/update_product.blade.php ENDPATH**/ ?>