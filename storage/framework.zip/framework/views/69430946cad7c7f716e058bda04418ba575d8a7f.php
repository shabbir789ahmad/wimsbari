<div>

    <div class="form-group">
      <label for="">Category <span class="text-danger">*</span>
      </label>
      <select name="category_id" id="category_id" class="form-control category_id">
        <option selected disabled hidden>Select Category</option>
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(request()->query('category')): ?>
          <option value="<?php echo e($category->id); ?>" <?php if(request()->query('category')==$category->id): ?> selected <?php endif; ?>><?php echo e($category->category_name); ?></option>
          <?php else: ?>
           <option value="<?php echo e($category->id); ?>" ><?php echo e($category->category_name); ?></option>
         <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
 
</div><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/same-code.blade.php ENDPATH**/ ?>