<?php $__env->startSection('content'); ?>
<style type="text/css">
	.dataTables_wrapper .dataTables_filter input{

padding: 1rem 4rem;
border:  1px solid #1E1E2D;
}

.dataTables_wrapper .dataTables_filter label{

font-size: 1.5vw;
font-weight: 700;
}
</style>
<div class="card">
  <div class="card-body">
   <div class="row">
	<div class="col-4 col-md-4">
       <h4 class="font-weight-bold">All Invoices</h4>
       		
	</div>
	<!-- <div class="col-8 col-md-8">
		<input type="text" id="myInputTextField" class="form-control border border-secondary" placeholder="Search By Invoice id, Name etc">
   </div> -->
  </div>
</div>
</div>

<div class="row">
	<div class="col-12">
		<div class="card">
		
			<div class="card-body pb-0">
				<?php if(count($orders) > 0): ?>

				<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th scope="col">Invoice Id</th>
								<th scope="col">Biller Name</th>
								<th scope="col">Product Name</th>
								<th scope="col">Date </th>
								<th scope="col">Quentity</th>
								<th scope="col">tax</th>
								<th scope="col">Total</th>
							
								<th scope="col"></th>
            </tr>
        </thead>
        <tbody>
        	
        	<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
			 <td class="p-0 col-1"> #<?php echo e($product->payment_id); ?> </td>
		     
		     <td ><?php echo e($product->biller_name); ?> </td>
		     <td ><?php echo e($product->product_name); ?></td>
		     <td ><?php echo e(date('d/m/Y',strtotime($product->created_at))); ?> </td>
			 <td><?php echo e($product->quentity); ?></td>
			 <td><?php echo e($product->tax); ?></td>
			 <td><?php echo e($product->sub_total); ?></td>
								
								<td class="col-1">
									<div class="d-flex">
								  <a href="<?php echo e(route('return.edit', ['return' => $product->id])); ?>" type="submit" class="btn btn-md btn-info">
										Return
									</a>
									<!-- <a href="<?php echo e(route('return.update', ['return' => $product->id])); ?>" type="submit" class="btn btn-xs btn-info ml-1">
										 Deatil
									</a> -->
								</div>
									
								</td>
							</tr>
      
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
				
				 
				<?php else: ?>
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => 'products','new' => 'products.create-bulk']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => 'products','new' => 'products.create-bulk']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php endif; ?>			
			</div>
		</form>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>

<script type="text/javascript">

$(document).ready(function() {
   oTable=$('#example').DataTable( {
        "paging":   false,
        "ordering": false,
        "info":     false
    });
//     $('#myInputTextField').keyup(function(){
//       oTable.search($(this).val()).draw() ;
// })
});

 $("#example_filter ").find('input').after("add your smiley here");

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/return/index.blade.php ENDPATH**/ ?>