<style type="text/css">
    th, td {
  padding: 15px;
}
</style>

<div class="row mt-0 pt-0 printer bari_invoice" id="printer">
 
<div class="container-fluid " id="">
     <div  style="font-size: 4vw; font-weight: 700; text-align:center; margin: 0mm; padding: 0mm; text-decoration: underline; display: flex; flex-direction:row; justify-content:space-between;">
        <img src="<?php echo e(asset('assets/defaults/logo.avif')); ?>" width="100%">
        
        </div>
    
      

      <div class="" style="display:flex; justify-content:space-between; flex-direction: row;  margin-top: 0%; padding-top: 0%;">
        <p style=" font-size: 3vw; display:flex; flex-direction:row; ;"><strong>SR NO:</strong> <span id="invoice_id"></span>  </p>
           <p style=" font-size: 3vw; display:flex; flex-direction:row; margin-left: auto;"><strong>Date#:</strong>  <?php echo e(date('y.m.d H:m:s A')); ?></p>
       
      </div>
      <div class="" style="display:flex; justify-content:center; flex-direction: row;  margin-top: 0%; padding-top: 0%;">
        <p style=" font-size: 5vw; font-weight: 900; text-decoration:underline" id="receipt_name">Quotation</p>
          
       
      </div>
     <div class="" style="display:flex; justify-content:space-between; flex-direction: row;  margin: 0%; padding: 0%;">
        <p style=" font-size: 4vw; display:flex; flex-direction:row; ;"><strong>To:</strong> <span id="invoice_client_name">Shabbir ahmad</span>  </p>
          
       
      </div>

        
   
   
     
 <table class="table table_css" cellspacing="0" cellpadding="0">
  <thead>
    <tr class="table_header2" >
      <th class="col-1 "  >Sr No</th>
      <th class="col-6">Description</th>
      <th class="col-1">Size</th>
      <th class="col-1">Qty.</th>
      <th class="col-1">Rate</th>
      <th class="col-2">Amount.</th>
    </tr>
  </thead>
  <tbody  id="bari_invoice_recipt" style="margin-top:5rem;">
  
   
  </tbody>
 </table>

    <div class="payment_data">
       <span>Total</span>
       <span id="invoice_total">0/-</span>
    </div>
    <div class="payment_data">
       <span>Delivery Charges(Client Responsibility)</span>
       <span id="invoice_delivery_charges">0/-</span>
    </div>
    <div class="payment_data">
       <span>Installation Charges(Client Responsibility)</span>
       <span id="invoice_install_charges">0/-</span>
    </div>
    <div class="payment_data">
       <span>Total Amount Payable</span>
       <span id="invoice_finale_total"> 72900/-</span>
    </div>
    
    <div style=" width: 100%;" >
     <div style="font-size: 4vw; font-weight: 700;text-decoration:underline;"> Terms & Conditions </div>
      
      <div class="term_conditon2" >
       <p style="display: flex; flex-direction:row"> <span style="font-size:3vw; font-weight:900">Payment:  75%</span><span style="font-size:3vw; margin-left: 1%;"> Advance With confirmation of order. Balance 25% before delivery payment</span></p>
       <p style="display: flex; flex-direction:row;"> <span style="font-size:3vw; font-weight:900">Payment:  18</span><span style="font-size:3vw; margin-left: 1%;">to 21 DAYSAFTER ADVANCE payment  With confirmation of order.</span></p>
       <p style="display: flex; flex-direction:row;"> <span style="font-size:3vw; font-weight:900">VAlidity: </span><span style="font-size:3vw; margin-left: 1%;">03-days from the date of quotation</span></p>
       <p > <span style="font-size:3vw; font-weight:900">Note:   Prices Exclusive of G.S.T & All Taxes.</span></p>
      </div>
    </div>


   <div style="position:absolute; bottom:12%; width: 100%;" id="bari_address">
     
      <hr style=" border: 2px solid #000;">
      <div class="term_conditon2" >
       <p style="font-weight:900"><strong>Office & Display Address:99-Shair Ali Road Near Of Expo Center,Joher Town, Lahore.</strong></p><br>
       <p style="margin-top:8mm"><strong>Factory Address: 36-km Main Multan Road, Lahore.</strong></p>
       <p style="margin-top:14mm"><strong>Cell No: 0302-4448392, 0333-9833392 </strong></p>
       <p style="margin-top:12mm"><strong>Email Address : bariengineering@gmail.com Web: www.baristeelrack.com</strong></p>
      </div>

      
    </div>
   
</div>

  </div><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/reciept/bari_invoice.blade.php ENDPATH**/ ?>