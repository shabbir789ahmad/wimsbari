<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('bari.product.update',['id'=>$product['id']])); ?>" method="POST" enctype="multipart/form-data" id="create_edit">
	<?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
	<div class="row">
	 <div class="col">
	  <div class="card">
	   <div class="card-body">
		<div class="row">

          <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label for="">
                                    Brand <span class="text-danger">*</span>
                                </label>
            <select name="bri_brand_id" class="form-control ">
            
               <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($brand->id); ?>" <?php echo e($product['bri_brand_id']== $brand->id ? 'selected' : ''); ?>><?php echo e($brand->brand_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger small"><?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            </div>
                        </div>

		  <div class="col-12 col-md-6">
		    <div class="form-group">
			 <label for="">Category
              <span class="text-danger">*</span>
			 </label>
			 <select name="bri_category_id" class="form-control">
			  
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($category->id); ?>" <?php echo e($product['bri_category_id']== $category->id ? 'selected' : ''); ?>><?php echo e($category->category_name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		     </select>
	         <span class="text-danger small"><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
						</div>
						
					</div>
					<div class="row" id="">
                        <input type="hidden" name="quotation" value="<?php echo e($product['quotation']); ?>">
						<div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                          Product Name <span class="text-danger">*</span>
                        </label>
                     <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'bri_product_name','value' => ''.e($product['bri_product_name']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                    </div>
                   </div>

                   <div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                          Product Size <span class="text-danger">*</span>
                        </label>
                     <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'size','value' => ''.e($product['size']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                    </div>
                   </div>

                   <div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                          Per Product Rate/Price  <span class="text-danger">*</span>
                        </label>
                     <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'rate','value' => ''.e($product['rate']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                    </div>
                   </div>
                   <div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                           Product Image  <span class="text-danger">*</span>
                        </label>
                     <input type="file" class="form-control" name="image" />
                    </div>
                   </div>
           </div>
           <div class="row"> 
         <?php $__currentLoopData = $product->components; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
                   <div class="col-12 col-md-4">
                            <div class="form-group">
                                <label for="">
                                     Total Quentity <span class="text-danger">*</span>
                                </label>
                                <input type="number" name="bri_quentity[]" class="form-control" value="<?php echo e($component->bri_quentity); ?>">
                                
                            </div>
                        </div>
                        
            <div class="col-12 col-md-4">
            <div class="form-group">
             <label for=""> Total Sizes 
              <span class="text-danger">*</span>
             </label>
			 <select class="form-control" name="bri_product_id[]" >
			  <?php $__currentLoopData = $productComponents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($product['id']==$component->product_id): ?>
               <option value="<?php echo e($product['id']); ?>"><?php echo e($product['product_name']); ?></option>
               <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 </select>

              </div>
            </div>
                   <input type="hidden" name="ids[]" value="<?php echo e($component['id']); ?>">
                        <div class="col-12 col-md-4">
                            <div class="form-group">
                                <label for="">
                                     Category Name <span class="text-danger">*</span>
                                </label>
                                
                                <input type="text" name="category_name[]" class="form-control" value="<?php echo e($component->category_name); ?>" readonly>
                            </div>
                        </div>
						
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					</div>
                  
                    
                    
					<div class="row">
						<div class="col-12">
							
                           
                            <button type="submit" id="create_button_submit" class="btn btn-primary" >
                                Update
                            </button>
                         
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('bari.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/bari/product/edit.blade.php ENDPATH**/ ?>