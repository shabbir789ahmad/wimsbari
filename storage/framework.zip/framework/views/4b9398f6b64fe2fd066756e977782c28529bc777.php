<div>
   
   <div class="form-group">
    <label for="">Search By Brand<span class="text-danger">*</span>
    </label>
    <select  id="brand_search" class="form-control ">
     <option selected disabled hidden>Search By Brand</option>
     <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(request()->query('brand_se')): ?>
      <option value="<?php echo e($brand['id']); ?>" <?php if(request()->query('brand_se')==$brand->id): ?> selected <?php endif; ?>><?php echo e($brand['brand_name']); ?></option>
       <?php else: ?>
      <option value="<?php echo e($brand['id']); ?>" ><?php echo e($brand['brand_name']); ?></option>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   </div>

</div><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/same-code2.blade.php ENDPATH**/ ?>