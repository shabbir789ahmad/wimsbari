<?php $attributes = $attributes->exceptProps(['type', 'message']); ?>
<?php foreach (array_filter((['type', 'message']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="toast-container" style="position: fixed; right: 2.5rem; top: 2.5rem; z-index: 1500;">
    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-delay="2500">
        <div id="toast-header" class="toast-header bg-<?php echo e(App\Helpers\ErrorMessages::color($type)); ?>">
            
            <strong id="toast-title" class="mr-auto">
                <?php echo e(App\Helpers\ErrorMessages::title($type)); ?>

            </strong>
            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div id="toast-body" class="toast-body">
            <?php echo e(App\Helpers\ErrorMessages::msg($type)); ?>

        </div>
    </div>
</div><?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/components/toast.blade.php ENDPATH**/ ?>