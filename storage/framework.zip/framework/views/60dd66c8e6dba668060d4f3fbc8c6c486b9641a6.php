<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('bari.product.store')); ?>" method="POST" enctype="multipart/form-data" id="create_edit">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-12 col-md-6">
							<div class="form-group">
								<label for="">
									Brand <span class="text-danger">*</span>
								</label>
			<select name="bri_brand_id" class="form-control ">
			<option selected disabled >Select Brand</option>
									<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($brand->id); ?>" <?php echo e(old('brand_id')== $brand->id ? 'selected' : ''); ?>><?php echo e($brand->brand_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<span class="text-danger small"><?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
						</div>
						<div class="col-12 col-md-6">
							<div class="form-group">
				<label for="">
						Category <span class="text-danger">*</span>
				</label>
				<select name="bri_category_id" id="bari_category_id" class="form-control">
									<option selected disabled >Select Category</option>
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id')== $category->id ? 'selected' : ''); ?>><?php echo e($category->category_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<span class="text-danger small"><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
						</div>
						
					</div>
					<div class="row" id="form_feild">
						
						
						
						
						
					</div>
					<?php if(request()->is('bari/quotation/create')): ?>
                    <input type="hidden" name="quotation" value="1">
					<?php endif; ?>
					
					<div class="row">
						<div class="col-12">

							<?php if(request()->is('bari/quotation/create')): ?>
							<button type="submit" id="create_button_submit" class="btn btn-primary" >
								Create Quotation
							</button>
							<?php else: ?>
							<button type="submit" id="create_button_submit" class="btn btn-primary" >
								Save
							</button>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('bari.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/bari/product/create.blade.php ENDPATH**/ ?>