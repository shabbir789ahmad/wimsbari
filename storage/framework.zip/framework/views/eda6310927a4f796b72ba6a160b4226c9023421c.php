<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('categories.update', ['id' => $category->id])); ?>" method="POST">
	<?php echo method_field('PUT'); ?>
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-body">
					<div class="form-group">
						<label for="">
							Category Name <span class="text-danger">*</span>
						</label>
						<input type="text" name="category_name" class="form-control" value="<?php echo e($category->category_name); ?>">
					</div>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.btn.update','data' => []]); ?>
<?php $component->withName('btn.update'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/categories/edit.blade.php ENDPATH**/ ?>