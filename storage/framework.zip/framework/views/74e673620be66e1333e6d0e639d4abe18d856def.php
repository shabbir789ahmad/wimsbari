<button id="_btnUpdate" type="btn" class="btn btn-primary">
	Update
</button><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/btn/update.blade.php ENDPATH**/ ?>