<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-12">
		<div class="form-group">
			<div class="btn-group" role="group" aria-label="Basic example">
				
                  <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">
					Create Product
				</a>
			
			</div>
		</div>
	</div>
</div>
<div class="row">
 <div class="col-md-4">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.same-code','data' => ['categories' => $categories]]); ?>
<?php $component->withName('same-code'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 </div>
 <div class="col-12 col-md-4">
   <div class="form-group">
    <label for="">Search by Sub Category <span class="text-danger">*</span>
    </label>
    <select name="sub_category_id[]" id="sub_category_id" class="form-control sub_category_id " multiple>
        <?php if(request()->query('sub_category')): ?>

        <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($subcategory['id']); ?>" <?php if(request()->query('sub_category')==$subcategory->id): ?> selected <?php endif; ?>><?php echo e($subcategory['sub_category_name']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
   </div>
  </div>
  <div class="col-md-4">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.same-code2','data' => ['brands' => $brands]]); ?>
<?php $component->withName('same-code2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['brands' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($brands)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
  </div>
</div>
<div class="row">
	<div class="col-12">
		<div class="card">
			
			<div class="card-body pb-0">
				<?php if(count($products) > 0): ?>

				<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th scope="col">Image</th>
								<th scope="col">Brand</th>
								<th scope="col">Name </th>
								<th scope="col">Category</th>
								<th scope="col">Sub Category</th>
								<th scope="col">Stock</th>
								<th scope="col">Sold</th>
								<th scope="col"></th>
            </tr>
        </thead>
        <tbody>
        	
        	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        	
            <tr>
								
								<td class="p-0 col-1">
									<img src="<?php echo e(asset('uploads/products/' . $product->product_image)); ?>"  alt="product image" class="border border-danger" width="80px" height="70px"  loading="lazy">
								</td>
								<td >
									<select class="form-control brands">
										<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  	<?php $__currentLoopData = $product->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($b->brand_id ==  $brand['id'] ): ?>
										<option value="<?php echo e($b['id']); ?>"><?php echo e($brand['brand_name']); ?></option>
										<?php endif; ?>
									
									  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</td>
								<td >
									
										<?php echo e($product->product_name); ?>

									
								</td>
									
							
								<td>
									<?php echo e($product->category_name); ?>

								</td>
								<td>
									<?php echo e($product->sub_category_name); ?>

								</td>
								<td>
									<select class="form-control">
										<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $__currentLoopData = $product->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($stock['pbrand_id'] == $b['id']): ?>
                   <option><?php echo e($stock['stock']); ?></option>
                  <?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
								</td>
								<td>
									<select class="form-control">
										<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $__currentLoopData = $product->brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($stock['pbrand_id'] == $b['id']): ?>
									<?php if($stock['stock_sold']==Null || $stock['stock_sold']==''): ?>
                   <option>0</option>
									<?php else: ?>
                   <option><?php echo e($stock['stock_sold']); ?></option>
                  <?php endif; ?>
                  <?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
								</td>
								<td class="col-1">
									<div class="d-flex">
								  <a href="<?php echo e(route('products.edit', ['id' => $product->id])); ?>" type="submit" class="btn btn-xs btn-info">
										Edit
									</a>
									
								</div>
									<div class="d-flex">
									<form  action="<?php echo e(route('products.stock',['id' => $product->id])); ?>" method="GET" class="stock_form " >
										<?php echo csrf_field(); ?>
										<input type="hidden" name="brandss" class="brnd">
								   <button class="btn btn-info btn-xs stc" >Stock</button>
								  </form>
									<form action="<?php echo e(route('products.destroy', ['id' => $product->id])); ?>" method="POST" class="ml-1" onsubmit="return confirmDelete()">
										<?php echo method_field('DELETE'); ?>
										<?php echo csrf_field(); ?>
										<button type="submit" class="btn btn-xs btn-danger">
											Delete
										</button>
								
									</form>
								</div>
								</td>
							</tr>
      
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  
				
				 
				<?php else: ?>
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => 'products','new' => 'products.create-bulk']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => 'products','new' => 'products.create-bulk']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php endif; ?>			
			</div>
		</form>
		</div>
	</div>
</div>






<form id="sub_category_form">
	<input type="hidden" name="sub_category" id="sub_category">
	<input type="hidden" name="brand_se" id="brand_se">
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>

<script type="text/javascript">

$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": false,
        "info":     false
    } );
});

  $('#sub_category_id').change(function(e){
  	e.preventDefault();
  	let id=$(this).val()
  	$('#sub_category').val(id)
  	$('#sub_category_form').submit()
  });

  $('#brand_search').change(function(e){
  	e.preventDefault();

  	let ids=$('#sub_category_id').val()
  	$('#sub_category').val(ids)
  	let id=$(this).val()
  	$('#brand_se').val(id)
  	$('#sub_category_form').submit()
  });

// $('.show-field').click(function(){

//  $(this).siblings().css('display','block')
//  $(this).css('display','none')
// });



$('.stock_form').on('submit', function(){

 let brand= $(this).parents('td').siblings('td').find('.brands').val();
$(this).children('.brnd').val(brand)
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/products/index.blade.php ENDPATH**/ ?>