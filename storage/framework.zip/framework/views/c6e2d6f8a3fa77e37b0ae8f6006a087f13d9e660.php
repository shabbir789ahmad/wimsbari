<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data" id="create_edit">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-12 col-md-3">
							<div class="form-group">
								<label for="">
									Brand <span class="text-danger">*</span>
								</label>
								<select name="where_house_id"  class="form-control ">
									<option selected disabled >Select WhereHouse</option>
									<?php $__currentLoopData = $wherehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wherehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($wherehouse->id); ?>" <?php echo e(old('id')== $wherehouse->id ? 'selected' : ''); ?>><?php echo e($wherehouse->where_house_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<span class="text-danger small"><?php $__errorArgs = ['where_house_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
						</div>
						<div class="col-12 col-md-3">
							<div class="form-group">
								<label for="">
									Brand <span class="text-danger">*</span>
								</label>
								<select name="brand_id" id="brand_id" class="form-control ">
									<option selected disabled >Select Brand</option>
									<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($brand->id); ?>" <?php echo e(old('brand_id')== $brand->id ? 'selected' : ''); ?>><?php echo e($brand->brand_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<span class="text-danger small"><?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
						</div>
						<div class="col-12 col-md-3">
							<div class="form-group">
								<label for="">
									Category <span class="text-danger">*</span>
								</label>
								<select name="category_id" id="category_id" class="form-control">
									<option selected disabled >Select Category</option>
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id')== $category->id ? 'selected' : ''); ?>><?php echo e($category->category_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<span class="text-danger small"><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
						</div>
						<div class="col-12 col-md-3">
							<div class="form-group">
								<label for="">
									Sub Category <span class="text-danger">*</span>
								</label>
								<select name="sub_category_id" id="sub_category_id" class="form-control">
									<option selected disabled hidden>Select Sub Category</option>
								</select>
								<span class="text-danger small"><?php $__errorArgs = ['sub_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12 col-md-6">
							<div class="form-group">
								<label for="">
									Product Name <span class="text-danger">*</span>
								</label>
								<?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_name']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
							</div>
						</div>
						
						
								<input name="sell_by[]" type="hidden" value="piece" />
                           <div class="col-12 col-md-6">
							<div class="form-group">
								<label for="">Price Per Component <span class="text-danger">*</span>
								</label>
								<?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'number','placeholder' => 'Price Per Component','name' => 'product_price_piece']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
							</div>
						</div>
						
					</div>
					
					
					
					
					<div class="row">
						
						<div class="col-12 col-md-6">
							<div class="form-group">
								<label for="">
									Stock<span class="text-danger">*</span>
								</label>
								<?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'stock']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
							</div>
						</div>
						
						<div class="col-12 col-md-6">
							<div class="form-group">
								<label for="">
									Purchasing Price
								</label>
								<?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'purchasing_price']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
							</div>
						</div>

					</div>
					<div class="col-12 col-md-2">
							<div class="form-group">
								<label for="">Image</label>
								<input type="file" name="image" id="upload-photo">
								<span class="text-danger small"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <i class="fa fa-times-circle"></i><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
							</div>
							<img id="preview" src="<?php echo e(asset('assets/defaults/ph.png')); ?>" class="img-fluid img-thumbnail" alt="">
						</div>
					
					<div class="row">
						<div class="col-12">
							<button type="button" id="create_button_submit" class="btn btn-primary">
								Save
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>

<script>

	$(document).ready(function() {

		$('#upload-photo').change(function() {

			updateImageSrc(document.getElementById('upload-photo'), document.getElementById('preview'));

		});

		$('#sell_by').change(function() {
           
			var selected = $(this).val();

			if (selected.includes("piece") && selected.includes("unit")) {
				$('#by-piece').removeClass('d-none');
				$('#by-unit').removeClass('d-none');
			}
			else if (selected.includes("piece")) {
				$('#by-piece').removeClass('d-none');
				$('#by-unit').addClass('d-none');
			} else if (selected.includes("unit")) {
				$('#by-piece').addClass('d-none');
				$('#by-unit').removeClass('d-none');
			}

		});
		
		$('#category_id').change(function() {
			$.ajax({
				url: baseURL + `categories/${ $(this).val() }/sub-categories`,
			})
			.done(function(res) {
				$('#sub_category_id').empty();
				$('#sub_category_id').append(`<option value="">Select Sub Category</option>`);
				$.each(res, function(index, val) {
					$('#sub_category_id').append(`
						<option value="${ val.id }">${ val.sub_category_name }</option>
					`);
				});
			})
			.fail(function() {
				console.log("error");
			})
			.always(function() {
				console.log("complete");
			});
		});
	});


$('.my-select').selectpicker();

$(document).ready(function() 
{
    var barcode="";
    $('#barcode').keydown(function(e) 
    {
        $(this).find('[autofocus]').focus();
            barcode=barcode+String.fromCharCode(code);
            $(this).val(barcode)
        
    });
});
$('#create_button_submit').click(function(){

	$('#create_edit').submit();
})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/products/create.blade.php ENDPATH**/ ?>