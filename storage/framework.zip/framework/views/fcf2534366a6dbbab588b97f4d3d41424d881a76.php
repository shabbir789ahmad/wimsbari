<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('barcode.store')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body ">
					<div class="row ">
					 <div class="col-12 col-md-4 mt-2">
					 <select  class="form-control border border-secondary" id="category_id">
						<option selected hidden disabled>Select Category</option>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($product['id']); ?>"><?php echo e($product['category_name']); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					 </select>
					</div>
					<div class="col-12 col-md-4 mt-2">
					<select  class="form-control border border-secondary" id="sub_category_id">
					
						
					</select>
				   </div>
				   <div class="col-12 col-md-3  mt-2">
					<select name="barcode_id" class="border border-secondary form-control ml-1" id="product">
						
					</select>
					</div>
					<div class="col-12 col-md-1 mt-2">
					<button class="btn btn-info  " type="submit">Generate</button>
				</div>
			</div>
				</div>
			</div>
		</div>
	</div>
</form>
<div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body pb-0">

				<?php if(count($barcodes) > 0): ?>

				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
						<thead class="thead-light">
							<tr>
								<th scope="col">Barcode</th>
								<th scope="col"></th>
								<th scope="col"></th>
								<th scope="col"></th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td class="col-3">
                                   <span><?php echo e(ucfirst($category['name'])); ?><span class="float-right">RO.<?php if($category['price']): ?><?php echo e($category['price']); ?> <?php else: ?> 0 <?php endif; ?></span></span><br>
									<?php echo $category->barcode; ?></td>
									<td class="col-3"></td>
									<td class="col-3"></td>
								<td class="col-3"><a href="<?php echo e(route('barcode.show',['barcode'=>$category->id])); ?>" class="btn btn-md btn-info">Print</a>
									<form action="<?php echo e(route('barcode.destroy', ['barcode' => $category->id])); ?>" method="POST" class="d-inline" onsubmit="return confirmDelete()">
										<?php echo method_field('DELETE'); ?>
										<?php echo csrf_field(); ?>
										<button type="submit" class="btn btn-md btn-danger">
											Delete
										</button>
								
									</form></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>

				<?php else: ?>

				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => 'barcode','new' => 'barcode.create']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => 'barcode','new' => 'barcode.create']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

				<?php endif; ?>
							
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

 <script type="text/javascript">

            $('#category_id').change(function() {
       
            $.ajax({
                url: `categories/${ $(this).val() }/sub-categories`,
            })
            .done(function(res) {
               
                $('#sub_category_id').empty();
                $('#sub_category_id').append(`<option selected disabled >Select Sub Category</option>`);
                $.each(res, function(index, val) {
                    $('#sub_category_id').append(`
                        <option value="${ val.id }">${ val.sub_category_name }</option>
                    `);
                });
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });
        });

             $('#sub_category_id').change(function() {
       
            $.ajax({
                url: `sub-categories/${ $(this).val() }/product`,
            })
            .done(function(res) {
               
                $('#product').empty();
                $('#product').append(`<option selected disabled >Select  Product</option>`);
                $.each(res, function(index, val) {
                    $('#product').append(`
                        <option value="${ val.id }">${ val.product_name }</option>
                    `);
                });
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/barcode/index.blade.php ENDPATH**/ ?>