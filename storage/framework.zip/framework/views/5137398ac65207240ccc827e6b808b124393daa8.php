<?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col-12">
		<div class="card">
			
			<div class="card-body pb-0">
				
				<?php if(count($invoices) > 0): ?>

				<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
           <tr>
            
            <th scope="col">Biller Name</th>
	        <th scope="col">Customer Name</th>
	        <th scope="col">Amount</th>
	        <th scope="col">Installation Charges</th>
	        <th scope="col">Delivery Charges</th>
	        <th scope="col"></th>
           </tr>
        </thead>
        <tbody>
        	
        	<?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	

        <tr>
        	<td><?php echo e($invoice['biller_name']); ?></td>
        	<td><?php echo e($invoice['customer_name']); ?></td>
        	<td><?php echo e($invoice['paying_amount']); ?></td>
        	<td><?php echo e($invoice['discount']); ?></td>
        	<td><?php echo e($invoice['tax']); ?></td>
		    <td class=" d-flex ">
		 
			<a href="<?php echo e(route('bari.quotation.edit', ['id' => $invoice->id])); ?>" type="submit" class="btn btn-md btn-info ">
			Detail
			</a>
			
		
		<form action="<?php echo e(route('bari.delete.order',['id'=>$invoice['id']])); ?>" method="POST" class="ml-1" onsubmit="return confirmDelete()">
		<?php echo method_field('DELETE'); ?>
		<?php echo csrf_field(); ?>
		<button type="submit" class="btn btn-md btn-danger ">
			Delete
		</button>
								
		</form>
		</td>
							</tr>
      
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  
				
				 
				<?php else: ?>
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => 'products','new' => 'products.create-bulk']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => 'products','new' => 'products.create-bulk']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php endif; ?>			
			</div>
		</form>
		</div>
	</div>
</div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>

<script type="text/javascript">



</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/bari/reciept/invoice.blade.php ENDPATH**/ ?>