<button id="_btnSave" type="btn" class="btn btn-primary">
	Save
</button><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/btn/save.blade.php ENDPATH**/ ?>