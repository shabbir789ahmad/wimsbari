<?php $attributes = $attributes->exceptProps(['resource', 'new']); ?>
<?php foreach (array_filter((['resource', 'new']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="alert alert-info" role="alert">
	<h4 class="alert-heading"><i class="fa fa-exclamation-circle"></i>&nbsp;No <?php echo e((new App\Helpers\StringHelper($resource))->ucfirst()->deSnake()->str()); ?> Found!</h4>
	<p>You have not added any <?php echo e((new App\Helpers\StringHelper($resource))->ucfirst()->deSnake()->str()); ?> yet!</p>
	<hr>
	<p class="mb-0">Click <a href="<?php echo e(route($new)); ?>">here</a> to add <?php echo e((new App\Helpers\StringHelper($resource))->ucfirst()->deSnake()->str()); ?></p>
</div><?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/components/alert/resource-empty.blade.php ENDPATH**/ ?>