<input 
    
    <?php echo e($attributes->merge(['id' => ($attributes->get('name') . '_inp'), 'class' => 'form-control' . $checkError($attributes->get('name')), 'type' => 'text', 'placeholder' => $attributes->get('placeholder') ?? Str::title(Str::of($attributes->get('name'))->replace('_', ' ')), 'value' => old($attributes->get('name'))])); ?>


/>

<?php $__errorArgs = [$attributes->get('name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="small text-danger"> <i class="fa fa-times-circle"></i> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/components/forms/input.blade.php ENDPATH**/ ?>