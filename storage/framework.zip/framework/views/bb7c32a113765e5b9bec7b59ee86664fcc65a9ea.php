<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WIMS</title>
<meta name="csrf-token" id="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('styles/app.css')); ?>">

    <style>
        .whole, .frac {
            font-size: 12px;
        }
        .frac {
            display: inline-block;
            position: relative;
            vertical-align: middle;
            letter-spacing: 0.001em;
            text-align: center;
        }
        .frac > span {
            display: block;
            padding: 0 0.1em;
        }
        /*.numerator {
            padding: 0;
            margin: 0;
            background-color: red;
        }*/
        .frac span.bottom {
            border-top: thin solid black;
            padding: 0;
        }
        .frac span.symbol {
            display: none;
        } 
    </style>

</head>
<body class="hold-transition sidebar-mini " style="background:#F0F0F2" >

    <div id="loading-container" class="loading-container d-none">
        <div class="loading">
            <i class="fas fa-fw fa-spinner fa-pulse fa-4x"></i>
            <div class="text-center mt-2">Loading</div>
        </div>
    </div>

    <div class="preloader flex-column justify-content-center align-items-center">
        <img class="animation__wobble" src="<?php echo e(asset('assets/defaults/logo.png')); ?>" alt="Logo" height="60" width="60">
    </div>
    <div class="wrapper">


        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.toast','data' => ['type' => session('flash')]]); ?>
<?php $component->withName('toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('flash'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <?php echo $__env->make('panel._includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('panel._includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-wrapper" style="background:#EDEDF0">

            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"></h1>
                        </div>
                        
                    </div>
                </div>
            </div>

            <div class="content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

        </div>



        <aside class="control-sidebar control-sidebar-dark">

            <div class="p-3">
                <a href="<?php echo e(route('logout')); ?>">Logout</a>
            </div>

        </aside>

        <footer class="main-footer">

            <div class="float-right d-none d-sm-inline">
                v0.1
            </div>

            <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="https://wasisoft.com">WasiSoft Technology</a>.</strong> All rights reserved.
        </footer>
    </div>

    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>

    <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.11.3/datatables.min.css"/>
 
   <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.11.3/datatables.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.js"></script>

    <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>
    <script src="<?php echo e(asset('js/payment.js')); ?>"></script>
    <script src="<?php echo e(asset('js/account.js')); ?>"></script>
    <script src="<?php echo e(asset('js/addexpense.js')); ?>"></script>
    <?php if(session()->has('flash')): ?>
    <script>

        



            $('.toast').toast('show');


        
    </script> 
    <?php endif; ?>

    <?php $__env->startSection('script'); ?>

    <script>

        $('#bari_category_id').change(function(){
           $.ajax({
                url: baseURL + `categories/${ $(this).val() }/sub-categories/product`,
            })
            .done(function(res) {
               
                $('#form_feild').empty();
                $('#form_feild').append(`

                   <div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                          Product Name <span class="text-danger">*</span>
                        </label>
                     <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'bri_product_name']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                    </div>
                   </div>

                   <div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                          Product Size <span class="text-danger">*</span>
                        </label>
                     <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'size']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                    </div>
                   </div>

                   <div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                          Per Product Rate/Price  <span class="text-danger">*</span>
                        </label>
                     <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'rate']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                    </div>
                   </div>
                   <div class="col-12 col-md-3">
                    <div class="form-group">
                        <label for="">
                           Product Image  <span class="text-danger">*</span>
                        </label>
                     <input type="file" class="form-control" name="image" />
                    </div>
                   </div>

                    `);
                $.each(res.categories, function(index, val) {
                   
                    
                var string = 
                    `
                        <div class="col-12 col-md-4">
                            <div class="form-group">
                                <label for="">
                                    Total ${val.sub_category_name} <span class="text-danger">*</span>
                                </label>
                                <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'bri_quentity[]']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-12 col-md-4">
                            <div class="form-group">
                                <label for="">
                                     ${val.sub_category_name} Sizes<span class="text-danger">*</span>
                                </label>
                                 
                      `;
                     
                     string=string+`
                       <select class="form-control" name="bri_product_id[]" id="sdsd">
                       `;
                        for(var val2 of res.product)
                        {
                          
                         if(val.id===val2.sub_category_id)
                          {

                          
                          string = string + `
                       
                         <option value="${val2.id}">${val2.product_name}</option>   
                              
                                `; 
                            }
                         } 
                  
                     
                       string = string + `
    
                         </select>
                            </div>
                        </div>

                        <div class="col-12 col-md-4">
                            <div class="form-group">
                                <label for="">
                                     ${val.sub_category_name} <span class="text-danger">*</span>
                                </label>
                                <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'category_name[]','value' => '${val.sub_category_name}','readonly' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                            </div>
                        </div>
                       `;
                      
                     $('#form_feild').append(string);
// dfdf
                
                });

                

            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });
                  
         })


        
           
      
     
        var baseURL = "<?php echo e(url("")); ?>" + "/";

        $('form:not(#_ajaxRequest)').submit(function() {
            
            var btn = $('#_btnSave, #_btnUpdate');

            btn.prop('disabled', 'true');
            btn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ');

        });

        function confirmDelete() {

            var cf = confirm('Are You Sure?');

            if (cf) {

                return true;

            } else {

                return false;
                
            }
            
        }

        function updateImageSrc(imageSelectInputId, previewImgTagId) {
            
            const [file] = imageSelectInputId.files;

            if (file) {
                previewImgTagId.src = URL.createObjectURL(file);
            }

        }

        $(window).on('unload', function() {
           


        });

    </script>
   

   <?php echo $__env->yieldSection(); ?>
    
</body>
</html>
<?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/bari/master.blade.php ENDPATH**/ ?>