<style type="text/css">
    th, td {
  padding: 15px;
}
</style>

<div class="row mt-0 pt-0 printer" id="printer">
 
<div class="container-fluid " id="">
  
        <div class="card-header " style=" display: flex; flex-direction: row; justify-content: center; text-align:center; padding: 0mm; margin: 0mm; text-decoration: underline;"><span style="font-size: 8vw; font-weight: 700; font-family: Open Sans;">BARI</span> <span style="font-size:6vw;margin: 9mm ; margin-left: 1%;">Engineering</span> 
        </div>
       
       <div class="" style="display:flex; justify-content:center; text-align:center; margin: 0mm; padding: 0mm;">
        
          <div style="display:flex; font-size: 3vw;flex-direction: column;margin: 0mm; padding: 0mm;">
                    
          <h4 class="heading" >TOTAL STORAGE SOLUTION</h4>
          <h4 class="heading text-danger" >THE BRILLIENT USE OF SPACE</h4>
        </div>
      </div>

      <div class="" style="display:flex; justify-content:space-between; flex-direction: row;  margin-top: 0%; padding-top: 0%;">
        
                    
          <p style=" font-size: 3vw; display: flex; justify-content:flex-start; flex-direction:row">Sr No: <span id="sr_no">12</span></p>
           <p style=" font-size: 3vw;">Date:  <?php echo e(date('y.m.d H:m:s A')); ?></p>
       
      </div>
      <div  style="font-size: 4vw; font-weight: 700; text-align:center; margin: 0mm; padding: 0mm; text-decoration: underline;">Estimate Invoice
        </div>

        <div  style="font-size: 3vw; font-weight: 700;  margin: 0mm; text-decoration: underline;">To:  <span id="client_name"></span>
        </div>  

     
    <table class="table  ">
  <thead>
    <tr class="table_header" >
      <th class="col-1"  >Sr No</th>
      <th class="col-4">Description</th>
      <th class="col-2">Size</th>
      <th class="col-1">Qty.</th>
      <th class="col-2">Rate</th>
      <th class="col-2">Amount</th>
    </tr>
  </thead>
  <tbody  id="bari_recipt">
    
   
    
   
  
  </tbody>
</table>

 
    

    

     <div  style="font-size:2.5vw; border: 1px solid #000; width: 100%; display: flex; flex-direction: row;  font-weight: 700;  padding: 0; ">
        <p style="margin-left: 5%;">Total</p>
        <p style="margin-left: auto; margin-right: 5%;" id="recipt_total"></p>
     </div> 
     <div  style="font-size:2.5vw; border-left: 2px solid #000; border-right: 2px solid #000; width: 100%; display: flex; flex-direction: row;  font-weight: 700; padding: 0; margin: 0; ">
        <p style="margin-left: 5%;">Delivery Charges(Client Responsibility)</p>
        <p style="margin-left: auto; margin-right: 5%;" id="d_charge">0</p>
     </div> 

     <div  style="font-size:2.5vw; border: 2px solid #000;  width: 100%; display: flex; flex-direction: row;  font-weight: 700; padding: 0; margin: 0; ">
        <p style="margin-left: 5%;">Installation Charges(Client Responsibility)</p>
        <p style="margin-left: auto; margin-right: 5%;" id="i_charge">0</p>
     </div> 

     <div  style="font-size:2.5vw; border: 2px solid #000; width: 100%; display: flex; flex-direction: row;  font-weight: 700;  padding: 0; margin: 0;"   >
        <p style="margin-left: 5%;">Total Amount</p>
        <p style="margin-left: auto; margin-right: 5%;" id="total_amount"></p>
     </div> 

     <div class="" style="display:flex;  flex-direction: row;  margin-top: 0%; padding-top: 3%; font-size: 3vw; font-weight: 700; text-decoration:underline;">
        Term & Conditions
      </div>
      
      <div class="term_conditon" >
       <p><strong>Payment:</strong></p>
       <p style="font-size: 2.1vw; margin-top:1mm;margin-left: 1mm;">75% Payment advance with confirmation or Order. Balance 25% before delivery payment</p>
      </div>

      <div class="term_conditon" >
       <p><strong class="mt-0">Delivery:</strong></p>
       <p style="font-size:2.1vw;margin-top:1mm;margin-left: 1mm;">18  TO 21  Days after the advance Payment with confirmation of Order.</p>
      </div>

       <div class="term_conditon" >
        <p><strong class="mt-0">Validity:</strong></p>
        <p style="font-size: 2.1vw;margin-top:1mm;margin-left: 1mm;"> 03-days from the date of quotation</p>
      </div>

      <div class="term_conditon" >
        <p><strong class="mt-0">Note:</strong></p>
        <p ><strong class="mt-0">Price Exclusive of G.S.T & All Taxes.</strong></p>
      </div>
    
   
</div>

  </div><?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/components/reciept/shelvereciept.blade.php ENDPATH**/ ?>