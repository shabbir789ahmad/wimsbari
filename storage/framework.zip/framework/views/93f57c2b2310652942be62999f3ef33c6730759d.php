<nav class="main-header navbar navbar-expand navbar-dark navbar-dark">

    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">Dashboard</a>
        </li>
    </ul>

    <ul class="navbar-nav ml-auto">

        

        
        <?php if(auth::user()->branch_id==3): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('bari.pos')); ?>" role="button">
                POS
                <i class="fas fa-cash-register"></i>
            </a>
        </li>
        <?php else: ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('pos.index')); ?>" role="button">
                POS
                <i class="fas fa-cash-register"></i>
            </a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                <i class="fas fa-expand-arrows-alt"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                <i class="fas fa-th-large"></i>
            </a>
        </li>
    </ul>
</nav><?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/panel/_includes/navbar.blade.php ENDPATH**/ ?>