<div>
    <div class="modal fade bd-example-modal-lg" id="payment-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Full Payment </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form  id="full_payment">
        
      <div class="modal-body" >
        <div class="row mt-2  ">
          <input type="hidden" id="biller_name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
          <input type="hidden" id="admin_id" class="form-control" value="<?php echo e(Auth::user()->id); ?>">
          <input type="text" class="form-control" id="reciept_type">
             <div class="col-md-6">

               <label class="font-weight-bold">Customer Name</label>
               <input type="text" id="customer_name" placeholder="Customer Name" class="form-control" value="">
               <span class="text-danger"><?php $__errorArgs = ['biller_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
             </div>
             <div class="col-md-6">
               <label class="font-weight-bold">Paying By</label>
               <select class="form-control" id="paying_by">
                <option value="cash">Cash</option>
                <option>Card</option>
               </select>
               <span class="text-danger"><?php $__errorArgs = ['Paying_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
             </div>
             
           </div>
           <div class="row mt-2">
            <div class="col-md-6">
              <label class="font-weight-bold">Payable Amount(Rs)</label>
               <input type="number" name="payable_amount" id="payable_amount" class="form-control grand_total"  readonly>
               <span class="text-danger"><?php $__errorArgs = ['payable_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
            <div class="col-md-6">
              <label class="font-weight-bold">Paying Amount(Rs)</label>
              <input type="number" name="paying_amount" id="paying_amount" class="form-control  grand_total"  autofocus>
              <span class="text-danger"><?php $__errorArgs = ['paying_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
          <?php if(Auth::user()->branch_id==1): ?>

         <div class="col-md-6 mt-2">
              <label class="font-weight-bold">Delivery Charges(Rs)</label>
              <input type="number" name="discount"  class="form-control  delivery_charges"  autofocus>
              <span class="text-danger"><?php $__errorArgs = ['delivery_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
            <div class="col-md-6 mt-2">
              <label class="font-weight-bold">Installation Charges </label>
              <input type="number" name="tax" id="tax"  class="form-control  install_charges"  autofocus>
              <span class="text-danger"><?php $__errorArgs = ['installation_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>


            <?php else: ?>



            <div class="col-md-6 mt-2">
              <label class="font-weight-bold">Discount</label>
              <input type="number" name="discount" id="discount"  class="form-control  "  autofocus>
              <span class="text-danger"><?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
            <div class="col-md-6 mt-2">
              <label class="font-weight-bold">Tax </label>
              <input type="number" name="tax" id="tax"  class="form-control  tax"  autofocus>
              <span class="text-danger"><?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
          <?php endif; ?>  
           </div>
        

         <input type="hidden" name="pro_ids"  class="form-control prod_id">
           

           <div class="row mt-5">
              <div class="col-md-6 d-flex">
               <p class="ml-1">Item</p>
               <p class="ml-auto mr-1 font-weight-bold " ><span class="items"></span><span class="quan"></span></p>
              </div>
              <div class="col-md-6 d-flex">
               <p class="ml-1">Total Payable(Rs)</p>
               <p class="ml-auto mr-1 font-weight-bold g_total2" id="total_payable">0</p>
              </div>
            </div>
            <div class="row border-top">
              <div class="col-md-6 d-flex">
               <p class="ml-1" >Total Paying (Rs)</p>
               <p class="ml-auto mr-1 font-weight-bold g_total2" >0</p>
              </div>
              <div class="col-md-6 d-flex">
               <p class="ml-1">Remaining(Rs) </p>
               <p class="ml-auto mr-1 font-weight-bold" id="remaining">0</p>
              </div>
            </div>
      </div>
      <div class="modal-footer d-flex">
          <!-- <div class="d-flex mr-auto">
           <button type="button" class="btn px-sm-2  payment font2 discount" > 
            Discount</button>
            <button type="button" class="btn order p-0 font2 partial-payment2" data-id="1">Temporary Account</button>
            <button type="button" class="btn font2 p-0 pbs hold-sale permanent-hold2" data-id="0">Permanent Account</button>
            
          </div> -->
          <?php if(auth::user()->branch_id==1): ?>
        <button class="btn btn-primary print" id="print2" type="button">Pay & Prints</button>
        <?php else: ?>
         <button class="btn btn-primary print" id="print" type="button">Pay & Print</button>
        <?php endif; ?>
      </div>
    </form>
    </div>
  </div>
</div>
</div><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/components/full-payment-component.blade.php ENDPATH**/ ?>