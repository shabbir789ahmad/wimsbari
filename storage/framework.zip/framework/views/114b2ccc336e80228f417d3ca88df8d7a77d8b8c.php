<?php $__env->startSection('content'); ?> 


<section class="mb-5 shadow bg-light pt-4">

  <div class="row">
    <div class="col-md-4 mb-4 mb-md-0">

      <div id="mdb-lightbox-ui"></div>

      <div class="mdb-lightbox">

        <div class="row product-gallery mx-1">

          <div class="col-12 mb-0">
            <figure class="view overlay rounded z-depth-1 main-img border">
           
              <img src="<?php echo e(asset('uploads/products/' . $products->product_image)); ?>" width="100%">
              
            </figure>
          </div>
         
        </div>

      </div>

    </div>
    <div class="col-md-8">
      <h5><?php echo e($products['product_name']); ?><span class="float-right"><button class="btn btn-info btn-sm mr-3" disabled  data-toggle="modal" data-target="#exampleModal">Update Product</button></span></h5>
           <p class="mb-2 text-muted text-uppercase small"><?php echo e($products['product_code']); ?></p>
    
           <p class="pt-1"><?php echo e($stock); ?></p>
           <hr>
      <div class="row">
        <div class="col-md-8">
          
            <div class="table-responsive">
             <table class="table table-sm table-borderless mb-0">
              <tbody>
               <tr>
                <th class="pl-0 w-25" scope="row"><strong>Category</strong></th>
                
                 <td><?php echo e($categories['category_name']); ?></td>
              
               </tr>
              <tr>
              <th class="pl-0 w-25" scope="row"><strong>Sub Category</strong></th>
              
              <td><?php echo e($sub_categories['sub_category_name']); ?></td>
             
            </tr>
            <tr>
              <th class="pl-0 w-25" scope="row"><strong>Brand</strong></th>
          
              <td  class="mb-5"><?php echo e($pbrand['brand_name']); ?></td>
              
            </tr>

            <tr>
              
            </tr>
         </tbody>
        </table>
      </div>
        </div>
        
      </div>   
    </div>
  </div>
</section>

<div class="d-flex">
<h3 type="button" class="  mr-1 mb-2" >All Stock </h3>

<button type="button" class="btn btn-primary btn-md add-stock mr-1 mb-2 ml-auto" >Add Stock</button>

</div>




<?php $count=1 ?>
<div class="row">

<?php $__currentLoopData = $brand_stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="col-12 col-md-6">
  <div class="card shadow">
   <div class="card-body">
     <h4 class="font-weight-bold">Stock <?php echo $count++ ?>
     
      <span class="float-right">
        <input type="checkbox" data-id="<?php echo e($stock['id']); ?>" name="stock_active" class="js-switchu"  <?php echo e($stock->active == 1 ? 'checked' : ''); ?> >
        <button class="btn btn-sm btn-info update-stock" data-id="<?php echo e($stock['id']); ?>" data-stock="<?php echo e($stock['stock']); ?>" data-pricepiece="<?php echo e($stock['product_price_piece']); ?>" data-pricepiecew="<?php echo e($stock['product_price_piece_wholesale']); ?>" data-priceunit="<?php echo e($stock['product_price_unit']); ?>"data-priceunitw="<?php echo e($stock['product_price_unit_wholesale']); ?>">Update
        </button>
        <form action="<?php echo e(route('stock.delete', ['id' => $stock->id])); ?>" method="POST" class="d-inline" onsubmit="return confirmDelete()">
         <?php echo method_field('DELETE'); ?>
          <?php echo csrf_field(); ?>
         <button type="submit" class="btn btn-sm btn-danger"> Delete</button>
        </form>
      </span>
     </h4><br>
     
    
       <p>Piece Stock <span class="float-right"><?php echo e($stock['stock']); ?></span></p>
       <p>Unit Stock <span class="float-right"><?php echo e($stock['stock_sold_kg']); ?></span></p>
       <p>Price Per Piece
        <?php if($stock['product_price_piece']): ?>
        <span class="float-right"><?php echo e($stock['product_price_piece']); ?></span>
        <?php else: ?>
        <span class="float-right">N/A</span>
        <?php endif; ?>
      </p>
       <p>WholeSale Price Per Piece
        <?php if($stock['product_price_piece_wholesale']): ?>
        <span class="float-right"><?php echo e($stock['product_price_piece_wholesale']); ?></span>
      <?php else: ?>
      <span class="float-right">N/A</span>
      <?php endif; ?>
    </p>
    <p>Product price Unit <?php if($stock['product_price_unit']): ?>
        <span class="float-right"><?php echo e($stock['product_price_unit']); ?></span>
      <?php else: ?>
      <span class="float-right">N/A</span>
      <?php endif; ?></p>
      <p>Product price Unit WholeSale <?php if($stock['product_price_unit_wholesale']): ?>
        <span class="float-right"><?php echo e($stock['product_price_unit_wholesale']); ?></span>
      <?php else: ?>
      <span class="float-right">N/A</span>
      <?php endif; ?></p>

       <p>Purchasing Price <span class="float-right"><?php echo e($stock['purchasing_price']); ?></span></p>
       <p>Creation Date <span class="float-right"><?php echo e(date('d/m/Y h:m:s A',strtotime($stock['created_at']))); ?></span></p>
   </div>
  </div>   
 </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>




<!-- Modal -->
<div class="modal fade" id="modal-stock" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Stock</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('stock.add')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="stock_id" value="<?php echo e($brands->id); ?>">
          <label for="">
             New Stock <span class="text-danger">*</span>
          </label>
          <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'stock']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
          <?php if($products['sell_by']=='piece' ||$products['sell_by']=='piece,unit'||$products['sell_by']=='piece, unit'): ?>
           <label for="">
             Price Per Piece <span class="text-danger">*</span>
           </label>
           <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
             <label for="">
              Wholesale Price per Piece <span class="text-danger">*</span>
           </label>
           <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece_wholesale']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if($products['sell_by']=='unit'||$products['sell_by']=='piece,unit'||$products['sell_by']=='piece, unit'): ?>
          <label for="">
           Price per unit <span class="text-danger">*</span>
          </label>
          <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_unit']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
          <label for="">
            Wholesale Price per Unit
            <span class="text-danger">*</span>
          </label>
          <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_unit_wholesale']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
         <?php endif; ?>
          <label for="">
             Purchasing Price <span class="text-danger">*</span>
          </label>
          <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'purchasing_price']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
      </div>
    </div>
  </div>
</div>



<div class="modal fade" id="stock-update" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Stock</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('all.stock')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="id" id="id">
          <label for="">
                  Add More Stock <span class="text-danger">*</span>
                </label>
                <input type="text" name="stock" id="st" class="form-control">
                          <?php if($products['sell_by']=='piece' ||$products['sell_by']=='piece,unit'||$products['sell_by']=='piece, unit'): ?>
           <label for="">
             Price Per Piece <span class="text-danger">*</span>
           </label>
           <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece','id' => 'pricep']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
             <label for="">
              Wholesale Price per Piece <span class="text-danger">*</span>
           </label>
           <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece_wholesale','id' => 'pricepw']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
          <?php endif; ?>
          <?php if($products['sell_by']=='unit'||$products['sell_by']=='piece,unit'||$products['sell_by']=='piece, unit'): ?>
          <label for="">
           Price per unit <span class="text-danger">*</span>
          </label>
          <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_unit','id' => 'priceu']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
          <label for="">
            Wholesale Price per Unit
            <span class="text-danger">*</span>
          </label>
          <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_unit_wholesale','id' => 'priceuw']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
         <?php endif; ?>
         
      </div>
      <div class="modal-footer">
        
        <button type="submit" class="btn btn-primary">Update</button>
        </form>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
          <?php echo method_field('PUT'); ?>
          <?php echo csrf_field(); ?>
          <input type="hidden" name="brand_id" value="<?php echo e($products->brand_id); ?>">
          <input type="hidden" name="category_id" value="<?php echo e($products->category_id); ?>">
          <input type="hidden" name="sub_category_id" value="<?php echo e($products->sub_category_id); ?>">
          <label for="">
                  Product Name<span class="text-danger">*</span>
                </label>
                <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_name','value' => ''.e($products->product_name).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                <label for="">
                  Product Code <span class="text-danger">*</span>
                </label>
                <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_code','value' => ''.e($products->product_code).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                <label for="">
                  Price Per Piece <span class="text-danger">*</span>
                </label>
                <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece','value' => ''.e($products->product_price_piece).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                 <label for="">
                  Wholesale Price per Piece <span class="text-danger">*</span>
                </label>
                <?php if (isset($component)) { $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Input::class, []); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'product_price_piece_wholesale','value' => ''.e($products->product_price_piece_wholesale).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f)): ?>
<?php $component = $__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f; ?>
<?php unset($__componentOriginal30600fd1d86901c8d1e2118fb7bb2cb7e3d1570f); ?>
<?php endif; ?>
                 
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
         </form>
      </div>
    </div>
  </div>
</div> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>
<script type="text/javascript">
  let elems2 = Array.prototype.slice.call(document.querySelectorAll('.js-switchu'));

elems2.forEach(function(html) {
    let switchery = new Switchery(html,  { size: ' small' });
});
</script>
<script type="text/javascript">
  $('.add-stock').click(function(){
 
  $('#modal-stock').modal('show')
 
  });

   $('.update-stock').click(function(){
 
  $('#stock-update').modal('show')
   let id=$(this).data('id')
   let pricepp=$(this).data('pricepiece')
   let priceppw=$(this).data('pricepiecew')
   let priceuu=$(this).data('priceunit')
   let priceuuw=$(this).data('priceunitw')
   let stock=$(this).data('stock')
 
   $('#pricep').val(pricepp)
   $('#pricepw').val(priceppw)
   $('#priceu').val(priceuu)
   $('#priceuw').val(priceuuw)
   
   
   $('#id').val(id)
   $('#st').val(stock)

  });
</script>
<script type="text/javascript">
 
  $(document).on('change','.js-switchu',function()
  {
   let active=$(this).prop('checked')===true? 1:0;
    $.ajax({
        
        type:'GET',
        url:"/active/stock",
        data:{'id':$(this).data('id'),'active':active},

    }).done(function(res){
     
    }).fail(function(){

    });

  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak/resources/views/panel/stock/stock.blade.php ENDPATH**/ ?>