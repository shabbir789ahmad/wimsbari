<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-12">
		<div class="form-group">
			<div class="btn-group" role="group" aria-label="Basic example">
				
			
			 <a href="<?php echo e(route('bari.create')); ?>" class="btn btn-primary ml3">
					Create Shelves
				</a>

				
			</div>
		</div>
	</div>
</div>
<div class="row">
 <div class="col-md-4">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.same-code','data' => ['categories' => $categories]]); ?>
<?php $component->withName('same-code'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 </div>
</div>
<div class="row">
	<div class="col-12">
		<div class="card">
			
			<div class="card-body pb-0">
				<?php if(count($products) > 0): ?>

				<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
           <tr>
            <th scope="col">Image</th>
	        <th scope="col">Product</th>
	        <th scope="col">Size</th>
	        <th scope="col">Rate/Price</th>
	        <th scope="col">Category</th>
	        <th scope="col">Brand</th>
	        <th scope="col"></th>
           </tr>
        </thead>
        <tbody>
        	
        	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	

        <tr>
		  <td class=" col-2">
			<img src="<?php echo e(asset('uploads/brand/' . $product->bri_image)); ?>"  alt="product image" class="border border-danger" width="100%" height="100rem"  loading="lazy">
		  </td>
		 
		  <td class="col-6 align-middle">
			<h3 class="font-weight-bold"><?php echo e($product->bri_product_name); ?></h3><p> With
        <?php $__currentLoopData = $product->components; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		   <?php echo e($component->bri_quentity); ?> <?php echo e($component->category_name); ?> 
		   +
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
		 </td>
		 <td class="align-middle text-center"><?php echo e($product->size); ?></td>
		 <td class="align-middle text-center"><?php echo e($product->rate); ?>/-</td>
		 <td class="align-middle text-center"><?php echo e($product->category_name); ?></td>
		 <td class="align-middle text-center"><?php echo e($product->brand_name); ?></td>

		 <td class="col-1 d-flex ">
		 
			<a href="<?php echo e(route('bari.edit', ['id' => $product->id])); ?>" type="submit" class="btn btn-md btn-info mt-4">
			Edit
			</a>
			
		
		<form action="<?php echo e(route('bari.product.delete', ['id' => $product->id])); ?>" method="POST" class="ml-1" onsubmit="return confirmDelete()">
		<?php echo method_field('DELETE'); ?>
		<?php echo csrf_field(); ?>
		<button type="submit" class="btn btn-md btn-danger mt-4">
			Delete
		</button>
								
		</form>
		</td>
							</tr>
      
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  
				
				 
				<?php else: ?>
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert.resource-empty','data' => ['resource' => 'products','new' => 'products.create-bulk']]); ?>
<?php $component->withName('alert.resource-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['resource' => 'products','new' => 'products.create-bulk']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
				<?php endif; ?>			
			</div>
		</form>
		</div>
	</div>
</div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('script'); ?>

<script type="text/javascript">

$(document).ready(function() {
    $('#example').DataTable( {
        "paging":   false,
        "ordering": false,
        "info":     false
    } );
});

 

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shabbir/laravel/wimspak-master/resources/views/bari/product/index.blade.php ENDPATH**/ ?>